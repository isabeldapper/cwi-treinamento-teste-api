package br.com.restassuredapitesting.tests.booking.tests.post;

import br.com.restassuredapitesting.tests.base.tests.BaseTest;

public class PostNewBookingTest extends BaseTest {

}
