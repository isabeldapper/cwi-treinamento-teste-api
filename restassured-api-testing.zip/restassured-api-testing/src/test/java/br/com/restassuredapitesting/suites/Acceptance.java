package br.com.restassuredapitesting.suites;

public interface Acceptance {
}
