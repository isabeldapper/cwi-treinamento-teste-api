package br.com.restassuredapitesting.tests.auth.tests;

import br.com.restassuredapitesting.tests.base.tests.BaseTest;

public class PostAuthTest extends BaseTest {
}
