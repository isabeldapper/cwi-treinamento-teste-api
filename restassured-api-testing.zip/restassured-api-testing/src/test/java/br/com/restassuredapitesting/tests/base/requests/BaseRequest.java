package br.com.restassuredapitesting.tests.base.requests;

public class BaseRequest {
}
